/*
  # Fix RLS Performance Issues
  
  This migration addresses critical performance issues identified by Supabase Performance Advisor:
  
  1. RLS Policy Auth Function Re-evaluation
     - Replace direct auth.uid() calls with scalar subqueries
     - Replace current_setting() calls with scalar subqueries
  
  2. Multiple Permissive RLS Policies Consolidation
     - Consolidate multiple permissive policies into single policies per role/action
     - Remove redundant policies
  
  3. Add Missing Indexes
     - Create indexes on commonly filtered columns
     - Add composite indexes for multi-column filters
  
  4. Performance Optimizations
     - Ensure all policies use indexed columns
     - Optimize policy expressions for better performance
*/

-- =============================================
-- 1. FIX RLS POLICY AUTH FUNCTION RE-EVALUATION
-- =============================================

-- Drop existing policies that have auth function re-evaluation issues
DROP POLICY IF EXISTS "Staff can view all businesses" ON businesses;
DROP POLICY IF EXISTS "Moderators can update businesses" ON businesses;
DROP POLICY IF EXISTS "Moderators can delete businesses" ON businesses;

-- Recreate policies with optimized auth function calls
CREATE POLICY "Staff can view all businesses"
  ON businesses
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = (SELECT auth.uid())
      AND admin_users.role IN ('staff', 'moderator', 'super_admin')
    )
  );

CREATE POLICY "Moderators can update businesses"
  ON businesses
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = (SELECT auth.uid())
      AND admin_users.role IN ('moderator', 'super_admin')
    )
  );

CREATE POLICY "Moderators can delete businesses"
  ON businesses
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = (SELECT auth.uid())
      AND admin_users.role IN ('moderator', 'super_admin')
    )
  );

-- =============================================
-- 2. CONSOLIDATE MULTIPLE PERMISSIVE POLICIES
-- =============================================

-- Drop all existing permissive policies
DROP POLICY IF EXISTS "Allow public insert access" ON businesses;
DROP POLICY IF EXISTS "Allow public insert access to businesses" ON businesses;
DROP POLICY IF EXISTS "Allow public read approved businesses" ON businesses;
DROP POLICY IF EXISTS "Public can view approved businesses" ON businesses;
DROP POLICY IF EXISTS "Allow authenticated users full access" ON businesses;

-- Create consolidated policies

-- Anonymous users can insert businesses (for public submissions)
CREATE POLICY "anon_insert_businesses"
  ON businesses
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- Anonymous users can view approved businesses
CREATE POLICY "anon_select_businesses"
  ON businesses
  FOR SELECT
  TO anon
  USING (status = 'approved');

-- Authenticated users can insert businesses
CREATE POLICY "authenticated_insert_businesses"
  ON businesses
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Authenticated users can view approved businesses
CREATE POLICY "authenticated_select_businesses"
  ON businesses
  FOR SELECT
  TO authenticated
  USING (status = 'approved');

-- Authenticated users can update their own businesses or if they're moderators
CREATE POLICY "authenticated_update_businesses"
  ON businesses
  FOR UPDATE
  TO authenticated
  USING (
    -- Users can update their own businesses
    (SELECT auth.uid()) = user_id
    OR
    -- Moderators can update any business
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = (SELECT auth.uid())
      AND admin_users.role IN ('moderator', 'super_admin')
    )
  );

-- Authenticated users can delete their own businesses or if they're moderators
CREATE POLICY "authenticated_delete_businesses"
  ON businesses
  FOR DELETE
  TO authenticated
  USING (
    -- Users can delete their own businesses
    (SELECT auth.uid()) = user_id
    OR
    -- Moderators can delete any business
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = (SELECT auth.uid())
      AND admin_users.role IN ('moderator', 'super_admin')
    )
  );

-- Authenticator role policies (for service role operations)
CREATE POLICY "authenticator_insert_businesses"
  ON businesses
  FOR INSERT
  TO authenticator
  WITH CHECK (true);

CREATE POLICY "authenticator_select_businesses"
  ON businesses
  FOR SELECT
  TO authenticator
  USING (true);

-- Dashboard user policies (for admin dashboard)
CREATE POLICY "dashboard_user_insert_businesses"
  ON businesses
  FOR INSERT
  TO dashboard_user
  WITH CHECK (true);

CREATE POLICY "dashboard_user_select_businesses"
  ON businesses
  FOR SELECT
  TO dashboard_user
  USING (true);

-- =============================================
-- 3. ADD MISSING INDEXES FOR PERFORMANCE
-- =============================================

-- Create indexes on commonly filtered columns
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_businesses_status 
  ON businesses(status);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_businesses_created_at 
  ON businesses(created_at);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_businesses_updated_at 
  ON businesses(updated_at);

-- Create composite indexes for common query patterns
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_businesses_status_created_at 
  ON businesses(status, created_at);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_businesses_user_id 
  ON businesses(user_id) 
  WHERE user_id IS NOT NULL;

-- Create index for admin_users role lookups (used in policies)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_admin_users_id_role 
  ON admin_users(id, role);

-- =============================================
-- 4. ADD HELPER FUNCTIONS FOR PERFORMANCE
-- =============================================

-- Create a helper function to get current user's admin role
-- This avoids repeated subqueries in policies
CREATE OR REPLACE FUNCTION get_current_user_admin_role()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT role FROM admin_users WHERE id = auth.uid();
$$;

-- Create a helper function to check if current user is moderator or admin
CREATE OR REPLACE FUNCTION is_current_user_moderator_or_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role IN ('moderator', 'super_admin')
  );
$$;

-- =============================================
-- 5. OPTIMIZE EXISTING POLICIES WITH HELPER FUNCTIONS
-- =============================================

-- Drop and recreate policies using helper functions for better performance
DROP POLICY IF EXISTS "Staff can view all businesses" ON businesses;
DROP POLICY IF EXISTS "Moderators can update businesses" ON businesses;
DROP POLICY IF EXISTS "Moderators can delete businesses" ON businesses;

-- Recreate with helper functions
CREATE POLICY "Staff can view all businesses"
  ON businesses
  FOR SELECT
  TO authenticated
  USING (get_current_user_admin_role() IS NOT NULL);

CREATE POLICY "Moderators can update businesses"
  ON businesses
  FOR UPDATE
  TO authenticated
  USING (is_current_user_moderator_or_admin());

CREATE POLICY "Moderators can delete businesses"
  ON businesses
  FOR DELETE
  TO authenticated
  USING (is_current_user_moderator_or_admin());

-- =============================================
-- 6. ADD COMMENTS FOR DOCUMENTATION
-- =============================================

COMMENT ON FUNCTION get_current_user_admin_role() IS 'Helper function to get current user admin role, optimized for RLS policies';
COMMENT ON FUNCTION is_current_user_moderator_or_admin() IS 'Helper function to check if current user has moderator or admin privileges';

-- Add comments to indexes
COMMENT ON INDEX idx_businesses_status IS 'Index on status column for filtering approved/pending businesses';
COMMENT ON INDEX idx_businesses_status_created_at IS 'Composite index for common query pattern: status + created_at ordering';
COMMENT ON INDEX idx_admin_users_id_role IS 'Composite index for admin role lookups in RLS policies';

-- =============================================
-- 7. VALIDATION QUERIES
-- =============================================

-- These queries can be run to validate the fixes:

-- Check that policies are properly consolidated (should return single policy per role/action)
-- SELECT schemaname, tablename, policyname, permissive, roles, cmd 
-- FROM pg_policies 
-- WHERE tablename = 'businesses' 
-- ORDER BY roles, cmd, policyname;

-- Check that indexes are being used (run EXPLAIN ANALYZE on representative queries)
-- EXPLAIN ANALYZE SELECT * FROM businesses WHERE status = 'approved' ORDER BY created_at DESC LIMIT 10;

-- Check that helper functions work correctly
-- SELECT get_current_user_admin_role();
-- SELECT is_current_user_moderator_or_admin();